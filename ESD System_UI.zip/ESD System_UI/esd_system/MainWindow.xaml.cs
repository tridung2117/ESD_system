﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using esd_system.ui;
using esd_system.utils;
using System.IO;
using System.Net.NetworkInformation;
using System.Net.Sockets;


namespace esd_system
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string loggedInUserName = ""; // Name of the logged-in user
        private string loggedInUserLevel = ""; // Privilege level of the logged-in user
        private PLCLib plcLib; // Instance of PLCLib
        private bool isMenuVisible = true; // Track menu visibility

        // File paths
        private string csvFilePath_plc_data => GetCsvFilePathPLCData("plc_data.csv");
        private string csvFilePath_measurement_data => GetCsvFilePathMeasurementData("measurement_data.csv");
        private string csvFilePath_plc_config => GetCsvFilePathPLCData("plc_config.csv");
        private string csvLinePath_read => GetCsvFilePathPLCData("plc_line_data_read.csv");
        private string csvLinePath_write => GetCsvFilePathPLCData("plc_line_data_write.csv");

        public MainWindow()
        {
            InitializeComponent();

            // Add event handler
            btn_login.Click += Btn_login_Click;
            btn_logout.Click += Btn_logout_Click;
            btn_monitor.Click += Btn_monitor_Click;
            btn_general_report.Click += Btn_general_report_Click;
            btn_setting.Click += Btn_setting_Click;
            btn_menu.Click += BtnMenu_Click;

            // Add an event to read PLC data when the form loads
            Loaded += MainWindow_Loaded;

            // Initially disable the buttons
            btn_monitor.IsEnabled = false;
            btn_general_report.IsEnabled = false;
            btn_setting.IsEnabled = false;

            // Clear the user info label
            lbl_user_info.Content = "Chưa đăng nhập";
            // Initialize PLCLib
            plcLib = new PLCLib();
            // Check and update PC address once at startup
            UpdatePLCAddress();
            // Check and update PC name once at startup
            UpdatePCName();
        }

        /// <returns>PC name as a string</returns>
        private string GetPCName()
        {
            try
            {
                return Environment.MachineName; // Retrieve the device name
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting PC name: {ex.Message}");
                return "Unknown PC";
            }
        }

        /// <summary>
        /// Updates lbl_pcname with the current PC name when the app starts.
        /// </summary>
        private void UpdatePCName()
        {
            string pcName = GetPCName();
            lbl_pcname.Content = $"PC Name: {pcName}"; // Update label
        }

        /// <returns>IP address as a string (e.g., "192.168.1.100")</returns>
        private string GetLocalIPAddress()
        {
            try
            {
                foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (nic.OperationalStatus == OperationalStatus.Up) // Check if network is active
                    {
                        foreach (UnicastIPAddressInformation ip in nic.GetIPProperties().UnicastAddresses)
                        {
                            if (ip.Address.AddressFamily == AddressFamily.InterNetwork) // IPv4 only
                            {
                                return ip.Address.ToString();
                            }
                        }
                    }
                }
                return "No IP Found"; // If no valid IP is found
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting IP: {ex.Message}");
                return "Error";
            }
        }

        /// <summary>
        /// Updates lbl_plcaddress with the current IP when the app starts.
        /// </summary>
        private void UpdatePLCAddress()
        {
            string ipAddress = GetLocalIPAddress();
            lbl_plcaddress.Content = $"{ipAddress}"; // Update label
        }

        private void BtnMenu_Click(object sender, RoutedEventArgs e)
        {
            if (isMenuVisible)
            {
                // left side collapsed
                left_border.Visibility = Visibility.Collapsed;
                user_info.Visibility = Visibility.Collapsed;
                log_io.Visibility = Visibility.Collapsed;
                stack_btn.Visibility = Visibility.Collapsed;
                bott_connection.Visibility = Visibility.Collapsed;

                // Expand the right grid to full width
                gd_rightSide.Margin = new Thickness(0, 0, 0, 0);
                // Expand the DynamicContentControl to full width
                right_border.Width = 1904; // Set to full window width
                right_border.Margin = new Thickness(0, 0, 0, 0); // Remove any margin
                DynamicContentControl.Width = 1904; // Set to full window width
                DynamicContentControl.Margin = new Thickness(0, 0, 0, 0); // Remove any margin
            }
            else
            {
                // left side visible
                left_border.Visibility = Visibility.Visible;
                user_info.Visibility = Visibility.Visible;
                log_io.Visibility = Visibility.Visible;
                stack_btn.Visibility = Visibility.Visible;
                bott_connection.Visibility = Visibility.Visible;

                // Restore the right grid margin
                gd_rightSide.Margin = new Thickness(320, 0, 0, 0);

                // Restore the original size and margin of DynamicContentControl
                right_border.Width = double.NaN; // Reset to "auto" (let the layout handle it)
                right_border.Margin = new Thickness(0, 0, 0, 0); // Restore any necessary margins here
                DynamicContentControl.Width = double.NaN; // Reset to "auto" (let the layout handle it)
                DynamicContentControl.Margin = new Thickness(0, 0, 0, 0); // Restore any necessary margins here
            }

            // Toggle the menu visibility state
            isMenuVisible = !isMenuVisible;
        }

        private void Btn_login_Click(object sender, RoutedEventArgs e)
        {
            // Open the UserLogin form
            UserLogin userLoginWindow = new UserLogin();

            // Show UserLogin as a modal dialog
            bool? result = userLoginWindow.ShowDialog();

            // Check if the user successfully logged in
            if (userLoginWindow.IsLoggedIn)
            {
                btn_monitor.IsEnabled = true;
                btn_general_report.IsEnabled = true;
                btn_setting.IsEnabled = true;
                btn_login.IsEnabled = false; // Disable login button after logging in

                loggedInUserName = userLoginWindow.UserName; // Get the user's name
                loggedInUserLevel = userLoginWindow.UserLevel; // Get the user's privilege level

                // Update the user info label
                lbl_user_info.Content = $"User: {loggedInUserName}";

                // Enable or disable buttons based on the user's level
                EnableButtonsBasedOnLevel();
            }
        }

        private void Btn_logout_Click(object sender, RoutedEventArgs e)
        {
            // Disable all buttons except login
            btn_monitor.IsEnabled = false;
            btn_general_report.IsEnabled = false;
            btn_setting.IsEnabled = false;
            btn_login.IsEnabled = true; // Re-enable login button

            // Reset user info
            loggedInUserName = "";
            loggedInUserLevel = "";
            lbl_user_info.Content = "Chưa đăng nhập"; // Default message when logged out
        }

        private string FindEsdSystemFolder()
        {
            // Start from the directory where the application is running
            string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;

            // Traverse upward to locate the "esd_system" folder
            while (!string.IsNullOrEmpty(currentDirectory))
            {
                string esdSystemPath = System.IO.Path.Combine(currentDirectory, "esd_system");
                if (Directory.Exists(esdSystemPath))
                {
                    return esdSystemPath; // Found the folder
                }

                // Move up one level
                currentDirectory = System.IO.Path.GetDirectoryName(currentDirectory);
            }

            // If not found, throw an exception
            throw new DirectoryNotFoundException("The 'esd_system' folder could not be found.");
        }

        private string GetCsvFilePathPLCData(string fileName)
        {
            // Find the "esd_system" folder
            string esdSystemFolder = FindEsdSystemFolder();

            // Return the full path to the file in "plc_data"
            return System.IO.Path.Combine(esdSystemFolder, "plc_data", fileName);
        }

        private string GetCsvFilePathMeasurementData(string fileName)
        {
            // Find the "esd_system" folder
            string esdSystemFolder = FindEsdSystemFolder();

            // Return the full path to the file in "plc_data"
            return System.IO.Path.Combine(esdSystemFolder, "measurement_data", fileName);
        }

        private void EnableButtonsBasedOnLevel() // 
        {

        }

        private void Btn_monitor_Click(object sender, RoutedEventArgs e)
        {
            DynamicContentControl.Content = new monitoring_control();

            // Update the label text
            lbl_mode_bar.Content = "Monitoring Control";
        }

        private void Btn_general_report_Click(object sender, RoutedEventArgs e)
        {
            // Update the label text
            lbl_mode_bar.Content = "General Report";
        }

        private void Btn_setting_Click(object sender, RoutedEventArgs e)
        {
            // Update the label text
            lbl_mode_bar.Content = "Settings";
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            //Connect to the PLC
            plcLib.ConnectToPLC(csvFilePath_plc_config);

            // Scan the CSV and connect to the PLC
            Dictionary<string, string> results = plcLib.ScanAndReadFromCSV(csvFilePath_plc_data);

            // Start the fast cycle to continuously update data
            plcLib.StartFastCycle(csvFilePath_plc_data, UpdatePLCData, 5000); // 1-second interval

            // Start reading PLC data every second
            plcLib.StartReadingFileEverySecond(csvLinePath_read, csvLinePath_write);
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Stop reading PLC data
            plcLib.StopReadingFile();
        }

        private void UpdatePLCData(Dictionary<string, string> results)
        {
            try
            {
                // Check if the file `csvFilePath_plc_data` exists
                if (!File.Exists(csvFilePath_plc_data))
                {
                    throw new FileNotFoundException("PLC data CSV file not found!", csvFilePath_plc_data);
                }

                // Read all lines from `csvFilePath_plc_data`
                var plcDataLines = File.ReadAllLines(csvFilePath_plc_data);
                if (plcDataLines.Length <= 1)
                {
                    throw new Exception("PLC data CSV file is empty or only contains a header!");
                }

                // Extract headers (Label Name column)
                List<string> headers = new List<string>();
                for (int i = 1; i < plcDataLines.Length; i++) // Skip the header row
                {
                    var columns = plcDataLines[i].Split(',');
                    if (columns.Length > 0)
                    {
                        headers.Add(columns[0].Trim()); // Add the "Label Name" (first column)
                    }
                }

                if (headers.Count == 0)
                {
                    throw new Exception("No labels found in the PLC data CSV file!");
                }

                // Check if the file `csvFilePath_measurement_data` exists
                bool isMeasurementDataFileExists = File.Exists(csvFilePath_measurement_data);

                // If the file doesn't exist, create it and write the header row
                if (!isMeasurementDataFileExists)
                {
                    using (var writer = new StreamWriter(csvFilePath_measurement_data, append: false))
                    {
                        writer.WriteLine(string.Join(",", headers)); // Write the header row
                    }
                }

                // Read existing measurement data
                var measurementDataLines = isMeasurementDataFileExists ? File.ReadAllLines(csvFilePath_measurement_data).ToList() : new List<string>();

                // Prepare a new row with updated values
                string[] newRow = new string[headers.Count]; // Create a row with the same number of columns as the header
                for (int i = 0; i < headers.Count; i++)
                {
                    string label = headers[i];
                    if (results.ContainsKey(label))
                    {
                        newRow[i] = results[label]; // Set the value for the respective label
                    }
                    else
                    {
                        newRow[i] = ""; // Leave empty if no value is available
                    }
                }

                // Append the new row to the measurement data file
                using (var writer = new StreamWriter(csvFilePath_measurement_data, append: true))
                {
                    writer.WriteLine(string.Join(",", newRow));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating measurement CSV file: {ex.Message}");
            }
        }
    }
}