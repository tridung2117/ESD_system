﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.IO;

namespace esd_system.ui.lines_layout.f4_a37
{
    /// <summary>
    /// Interaction logic for gia_cong_truc_f4_a37.xaml
    /// </summary>
    public partial class gia_cong_truc_f4_a37 : Window
    {
        private string csvFilePathMeasurementData = @"C:\Users\rsd24\Documents\ESD System\esd_system\measurement_data\measurement_data.csv";
        private DispatcherTimer timer; // Timer for real-time updates

        public gia_cong_truc_f4_a37()
        {
            InitializeComponent();

            // Initialize and start the timer
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1); // Update every 1 second
            timer.Tick += Timer_Tick; // Hook up the event handler
            timer.Start(); // Start the timer
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // Call the method to read the latest data from the CSV file
            UpdateLabelFromCsv();
        }

        private void UpdateLabelFromCsv()
        {
            try
            {
                // Check if the CSV file exists
                if (!File.Exists(csvFilePathMeasurementData))
                {
                    lbl_f4_a37_s25_tb1.Content = "File not found!";
                    return;
                }

                // Read all lines of the CSV file
                var lines = File.ReadAllLines(csvFilePathMeasurementData);

                // Ensure there are at least two lines (header + one row of data)
                if (lines.Length <= 1)
                {
                    lbl_f4_a37_s25_tb1.Content = "No data available!";
                    return;
                }

                // Parse the header row to find the label's column index
                var headers = lines[0].Split(','); // Split the first row (header)

                // Find the index of the column matching the label's name
                int columnIndex = Array.IndexOf(headers, "lbl_f4_a37_s25_tb1");
                if (columnIndex == -1)
                {
                    lbl_f4_a37_s25_tb1.Content = "Label not found in header!";
                    return;
                }

                // Get the last row of data
                var lastRow = lines.Last().Split(',');

                // Check if the last row has enough columns
                if (lastRow.Length <= columnIndex)
                {
                    lbl_f4_a37_s25_tb1.Content = "Invalid data!";
                    return;
                }

                // Update the label with the value from the corresponding column
                lbl_f4_a37_s25_tb1.Content = lastRow[columnIndex];
            }
            catch (Exception ex)
            {
                // Handle any errors and display them on the label
                lbl_f4_a37_s25_tb1.Content = $"Error: {ex.Message}";
            }
        }
    }
}
