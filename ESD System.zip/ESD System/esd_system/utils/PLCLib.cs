﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using Mitsubishi.tuhocplc.FXcpu;
using System.Linq;
using System.Timers;
namespace esd_system.utils
{
    public class PLCLib
    {
        private Enet_Fx3u fx3u; // Mitsubishi PLC object
        private Dictionary<string, string> plcDataResults; // Stores PLC data with Label Name as the key
        private bool isConnected = false;
        private string currentBrand = ""; // Tracks the PLC brand in use
        private Timer fileReadTimer; // Timer for 1-second file reading

        public PLCLib()
        {
            fx3u = new Enet_Fx3u();
            plcDataResults = new Dictionary<string, string>();
            
        }

        // Connect to a Mitsubishi PLC
        private void ConnectToMitsu(string ipAddress, int port)
        {
            try
            {
                fx3u.Connect(ipAddress, port);

                if (fx3u.IsConnected)
                {
                    isConnected = true;
                    Console.WriteLine($"Successfully connected to Mitsubishi PLC at {ipAddress}:{port}");
                }
                else
                {
                    isConnected = false;
                    throw new Exception($"Failed to connect to Mitsubishi PLC at {ipAddress}:{port}");
                }
            }
            catch (Exception ex)
            {
                isConnected = false;
                Console.WriteLine($"Error connecting to Mitsubishi PLC: {ex.Message}");
                MessageBox.Show($"Error connecting to Mitsubishi PLC: {ex.Message}", "Connection Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Modular connection logic to handle different PLC brands
        public void ConnectToPLC(string connectionCsvFilePath)
        {
            try
            {
                // Check if the connection CSV file exists
                if (!File.Exists(connectionCsvFilePath))
                {
                    throw new FileNotFoundException("Connection CSV file not found!", connectionCsvFilePath);
                }

                // Read the connection details from the CSV file
                var lines = File.ReadAllLines(connectionCsvFilePath);

                // Ensure the CSV file has at least a header and one row of data
                if (lines.Length <= 1)
                {
                    throw new Exception("Connection CSV file is empty or only contains the header!");
                }

                // Parse the first row of connection details (IP Address, Port, Brand)
                var columns = lines[1].Split(',');

                if (columns.Length != 3)
                {
                    throw new Exception("Invalid format in connection CSV file. Expected format: IP Address,Port,Brand");
                }

                string ipAddress = columns[0].Trim(); // IP Address
                int port = int.Parse(columns[1].Trim()); // Port
                string brand = columns[2].Trim().ToLower(); // PLC Brand

                currentBrand = brand; // Track the current PLC brand

                // Connect based on the PLC brand
                switch (brand)
                {
                    case "mitsu": // Mitsubishi PLC
                        ConnectToMitsu(ipAddress, port);
                        break;

                    default:
                        throw new Exception($"Unsupported PLC brand: {brand}. Only 'mitsu' is supported for now.");
                }
            }
            catch (Exception ex)
            {
                isConnected = false;
                Console.WriteLine($"Error connecting to PLC: {ex.Message}");
                MessageBox.Show($"Error connecting to PLC: {ex.Message}", "Connection Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Read data from the PLC for a single data address
        public string ReadFromMitsu(string dataAddress)
        {
            ushort[] readData = new ushort[1]; // Default value

            if (!isConnected || fx3u == null)
            {
                Console.WriteLine("Not connected to the PLC or fx3u object is null.");
                return readData[0].ToString();
            }

            if (string.IsNullOrEmpty(dataAddress) || !dataAddress.StartsWith("D"))
            {
                Console.WriteLine($"Invalid data address format: {dataAddress}. Must start with 'D'.");
                return readData[0].ToString();
            }

            if (!ushort.TryParse(dataAddress.Substring(1), out ushort address))
            {
                Console.WriteLine($"Failed to parse data address: {dataAddress}. Ensure the address is a valid number after 'D'.");
                return readData[0].ToString();
            }

            bool success = fx3u.MemoryAreaRead(MitsubishiMemory.D, address, 1, out readData);

            if (!success || readData == null || readData.Length == 0)
            {
                Console.WriteLine($"Failed to read data from address: {dataAddress}");
                return readData[0].ToString();
            }

            return readData[0].ToString();
        }

        public bool ReadBitFromMitsu(string bitAddress)
        {
            try
            {
                // Validate input
                if (string.IsNullOrEmpty(bitAddress) || !bitAddress.StartsWith("M"))
                    throw new ArgumentException("Invalid bit address. It must start with 'M'.");

                // Extract the numeric part of the bit address (e.g., "M0" -> 0)
                string numericPart = bitAddress.Substring(1); // Remove the 'M'
                if (!ushort.TryParse(numericPart, out ushort startBit))
                    throw new ArgumentException($"Invalid bit address '{bitAddress}'. The numeric part is not valid.");

                // Read 1 bit from the specified address
                bool[] bitValue = new bool[1];
                fx3u.BitsAreaRead(MitsubishiMemory.M, startBit, 1, out bitValue);

                // Return the bit value
                return bitValue[0];
            }
            catch (Exception ex)
            {
                // Handle and log exceptions (if needed)
                Console.WriteLine($"Error reading bit from PLC: {ex.Message}");
                return false; // Return a default value in case of error
            }
        }

        // Scan and read all label values from the CSV file
        public Dictionary<string, string> ScanAndReadFromCSV(string csvFilePath)
        {
            try
            {
                if (!File.Exists(csvFilePath))
                {
                    throw new FileNotFoundException("Data CSV file not found!", csvFilePath);
                }

                var lines = File.ReadAllLines(csvFilePath);

                if (lines.Length <= 1)
                {
                    throw new Exception("Data CSV file is empty or only contains the header!");
                }

                plcDataResults.Clear(); // Clear previous results

                for (int i = 1; i < lines.Length; i++) // Skip the header
                {
                    var line = lines[i].Trim();
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    var columns = line.Split(',');

                    if (columns.Length != 2)
                    {
                        Console.WriteLine($"Invalid row format at line {i + 1}: {line}");
                        continue;
                    }

                    string labelName = columns[0].Trim();   // Label Name
                    string dataAddress = columns[1].Trim(); // Data Address

                    try
                    {
                        if (isConnected)
                        {
                            string value = ReadFromMitsu(dataAddress);
                            plcDataResults[labelName] = value;
                        }
                        else
                        {
                            plcDataResults[labelName] = "Not connected to PLC";
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error reading data for label '{labelName}': {ex.Message}");
                        plcDataResults[labelName] = "Error";
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing data CSV file: {ex.Message}");
                MessageBox.Show($"Error processing data CSV file: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            return plcDataResults;
        }

        // Method to start reading the CSV file every second
        public void StartReadingFileEverySecond(string csvPathRead, string csvPathWrite)
        {
            try
            {
                // Ensure the input file exists
                if (!File.Exists(csvPathRead))
                {
                    throw new FileNotFoundException($"Input CSV file not found: {csvPathRead}");
                }

                // Initialize the timer if not already done
                if (fileReadTimer == null)
                {
                    fileReadTimer = new Timer(1000); // Set interval to 1 second (1000ms)
                    fileReadTimer.Elapsed += (sender, e) =>
                    {
                        try
                        {
                            // Call the LineDataReadFromMitsu function to process the CSV
                            LineDataReadFromMitsu(csvPathRead, csvPathWrite);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error during real-time file processing: {ex.Message}");
                        }
                    };
                    fileReadTimer.AutoReset = true; // Ensures the timer repeats
                }

                // Start the timer
                fileReadTimer.Start();
                Console.WriteLine($"Started reading file '{csvPathRead}' every 1 second.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error starting file reading: {ex.Message}");
            }
        }

        // Method to stop the timer
        public void StopReadingFile()
        {
            if (fileReadTimer != null && fileReadTimer.Enabled)
            {
                fileReadTimer.Stop();
                Console.WriteLine("Stopped reading file.");
            }
        }

        // Process the CSV: Read all data addresses in the CSV and write the corresponding data
        public void LineDataReadFromMitsu(string csvPathRead, string csvPathWrite)
        {
            try
            {
                // Step 1: Read the CSV file into memory
                var csvLines = File.ReadAllLines(csvPathRead).ToList();

                // Ensure the file is not empty
                if (csvLines.Count == 0)
                    throw new Exception("The input CSV file is empty.");

                // Step 2: Parse the header (first row) and initialize the output data
                var headers = csvLines[0].Split(',');
                var outputData = new List<string[]>(); // To store the output CSV data

                // Add the headers as the first row of the output
                outputData.Add(headers);

                // Step 3: Process each column and fetch PLC data
                int columnCount = headers.Length;
                for (int col = 0; col < columnCount; col++)
                {
                    var columnData = new List<string>();

                    // For each row in the column (starting from row 2), read the data address
                    for (int row = 1; row < csvLines.Count; row++)
                    {
                        var rowData = csvLines[row].Split(',');

                        if (col < rowData.Length) // Ensure column exists in the current row
                        {
                            var dataAddress = rowData[col];

                            if (!string.IsNullOrWhiteSpace(dataAddress)) // Skip empty addresses
                            {
                                try
                                {
                                    // Fetch data from the PLC
                                    string data = ReadFromMitsu(dataAddress);
                                    columnData.Add(data);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine($"Error reading address '{dataAddress}': {ex.Message}");
                                    columnData.Add("Error"); // Add "Error" for failed reads
                                }
                            }
                            else
                            {
                                columnData.Add(""); // Add empty for blank addresses
                            }
                        }
                        else
                        {
                            columnData.Add(""); // Add empty if column is missing in the row
                        }
                    }

                    // Add the column data to the corresponding rows in outputData
                    for (int i = 0; i < columnData.Count; i++)
                    {
                        if (i + 1 >= outputData.Count)
                            outputData.Add(new string[columnCount]); // Ensure the row exists in outputData

                        outputData[i + 1][col] = columnData[i];
                    }
                }

                // Step 4: Write the output data to the output CSV file
                var outputLines = outputData.Select(row => string.Join(",", row));
                File.WriteAllLines(csvPathWrite, outputLines);

                Console.WriteLine($"CSV processing complete. Data written to '{csvPathWrite}'.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing CSV: {ex.Message}");
            }
        }

        // Continuously read data in a fast cycle
        public void StartFastCycle(string dataCsvFilePath, Action<Dictionary<string, string>> updateCallback, int interval = 1000)
        {
            Timer timer = new System.Timers.Timer(interval);
            timer.Elapsed += (sender, e) =>
            {
                Dictionary<string, string> results = ScanAndReadFromCSV(dataCsvFilePath);

                if (results != null)
                {
                    updateCallback?.Invoke(results);
                }
            };
            timer.AutoReset = true;
            timer.Start();
        }
    }
}