﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using esd_system.ui;
using esd_system.utils;
using System.IO;


namespace esd_system
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string loggedInUserName = ""; // Name of the logged-in user
        private string loggedInUserLevel = ""; // Privilege level of the logged-in user
        private PLCLib plcLib; // Instance of PLCLib

        // File paths
        private string csvFilePath_plc_data => GetCsvFilePathPLCData("plc_data.csv");
        private string csvFilePath_measurement_data => GetCsvFilePathMeasurementData("measurement_data.csv");
        private string csvFilePath_plc_config => GetCsvFilePathPLCData("plc_config.csv");
        private string csvLinePath_read => GetCsvFilePathPLCData("plc_line_data_read.csv");
        private string csvLinePath_write => GetCsvFilePathPLCData("plc_line_data_write.csv");

        public MainWindow()
        {
            InitializeComponent();

            // Add event handler
            btn_login.Click += Btn_login_Click;
            btn_monitor.Click += Btn_monitor_Click;
            btn_general_report.Click += Btn_general_report_Click;
            btn_setting.Click += Btn_setting_Click;

            // Add an event to read PLC data when the form loads
            Loaded += MainWindow_Loaded;

            // Initially disable the buttons
            btn_monitor.IsEnabled = false;
            btn_general_report.IsEnabled = false;
            btn_setting.IsEnabled = false;

            // Clear the user info label
            lbl_user_info.Content = "Chưa đăng nhập";
            // Initialize PLCLib
            plcLib = new PLCLib();
        }

        private void Btn_login_Click(object sender, RoutedEventArgs e)
        {
            // Open the UserLogin form
            UserLogin userLoginWindow = new UserLogin();

            // Show UserLogin as a modal dialog
            bool? result = userLoginWindow.ShowDialog();

            // Check if the user successfully logged in
            if (userLoginWindow.IsLoggedIn)
            {
                btn_monitor.IsEnabled = true;
                btn_general_report.IsEnabled = true;
                btn_setting.IsEnabled = true;
                loggedInUserName = userLoginWindow.UserName; // Get the user's name
                loggedInUserLevel = userLoginWindow.UserLevel; // Get the user's privilege level

                // Update the user info label
                lbl_user_info.Content = $"User: {loggedInUserName}";

                // Enable or disable buttons based on the user's level
                EnableButtonsBasedOnLevel();
            }
        }

        private string FindEsdSystemFolder()
        {
            // Start from the directory where the application is running
            string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;

            // Traverse upward to locate the "esd_system" folder
            while (!string.IsNullOrEmpty(currentDirectory))
            {
                string esdSystemPath = System.IO.Path.Combine(currentDirectory, "esd_system");
                if (Directory.Exists(esdSystemPath))
                {
                    return esdSystemPath; // Found the folder
                }

                // Move up one level
                currentDirectory = System.IO.Path.GetDirectoryName(currentDirectory);
            }

            // If not found, throw an exception
            throw new DirectoryNotFoundException("The 'esd_system' folder could not be found.");
        }

        private string GetCsvFilePathPLCData(string fileName)
        {
            // Find the "esd_system" folder
            string esdSystemFolder = FindEsdSystemFolder();

            // Return the full path to the file in "plc_data"
            return System.IO.Path.Combine(esdSystemFolder, "plc_data", fileName);
        }

        private string GetCsvFilePathMeasurementData(string fileName)
        {
            // Find the "esd_system" folder
            string esdSystemFolder = FindEsdSystemFolder();

            // Return the full path to the file in "plc_data"
            return System.IO.Path.Combine(esdSystemFolder, "measurement_data", fileName);
        }

        private void EnableButtonsBasedOnLevel() // 
        {

        }

        private void Btn_monitor_Click(object sender, RoutedEventArgs e)
        {
            DynamicContentControl.Content = new monitoring_control();
        }

        private void Btn_general_report_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Btn_setting_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            //Connect to the PLC
            plcLib.ConnectToPLC(csvFilePath_plc_config);

            // Scan the CSV and connect to the PLC
            Dictionary<string, string> results = plcLib.ScanAndReadFromCSV(csvFilePath_plc_data);

            // Start the fast cycle to continuously update data
            plcLib.StartFastCycle(csvFilePath_plc_data, UpdatePLCData, 5000); // 1-second interval

            // Start reading PLC data every second
            plcLib.StartReadingFileEverySecond(csvLinePath_read, csvLinePath_write);
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Stop reading PLC data
            plcLib.StopReadingFile();
        }

        private void UpdatePLCData(Dictionary<string, string> results)
        {
            try
            {
                // Check if the file `csvFilePath_plc_data` exists
                if (!File.Exists(csvFilePath_plc_data))
                {
                    throw new FileNotFoundException("PLC data CSV file not found!", csvFilePath_plc_data);
                }

                // Read all lines from `csvFilePath_plc_data`
                var plcDataLines = File.ReadAllLines(csvFilePath_plc_data);
                if (plcDataLines.Length <= 1)
                {
                    throw new Exception("PLC data CSV file is empty or only contains a header!");
                }

                // Extract headers (Label Name column)
                List<string> headers = new List<string>();
                for (int i = 1; i < plcDataLines.Length; i++) // Skip the header row
                {
                    var columns = plcDataLines[i].Split(',');
                    if (columns.Length > 0)
                    {
                        headers.Add(columns[0].Trim()); // Add the "Label Name" (first column)
                    }
                }

                if (headers.Count == 0)
                {
                    throw new Exception("No labels found in the PLC data CSV file!");
                }

                // Check if the file `csvFilePath_measurement_data` exists
                bool isMeasurementDataFileExists = File.Exists(csvFilePath_measurement_data);

                // If the file doesn't exist, create it and write the header row
                if (!isMeasurementDataFileExists)
                {
                    using (var writer = new StreamWriter(csvFilePath_measurement_data, append: false))
                    {
                        writer.WriteLine(string.Join(",", headers)); // Write the header row
                    }
                }

                // Read existing measurement data
                var measurementDataLines = isMeasurementDataFileExists ? File.ReadAllLines(csvFilePath_measurement_data).ToList() : new List<string>();

                // Prepare a new row with updated values
                string[] newRow = new string[headers.Count]; // Create a row with the same number of columns as the header
                for (int i = 0; i < headers.Count; i++)
                {
                    string label = headers[i];
                    if (results.ContainsKey(label))
                    {
                        newRow[i] = results[label]; // Set the value for the respective label
                    }
                    else
                    {
                        newRow[i] = ""; // Leave empty if no value is available
                    }
                }

                // Append the new row to the measurement data file
                using (var writer = new StreamWriter(csvFilePath_measurement_data, append: true))
                {
                    writer.WriteLine(string.Join(",", newRow));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating measurement CSV file: {ex.Message}");
            }
        }
    }
}