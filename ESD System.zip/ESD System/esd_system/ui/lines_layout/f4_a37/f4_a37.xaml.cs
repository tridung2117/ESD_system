﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using esd_system.ui;

namespace esd_system.ui.lines_layout.f4_a37
{
    /// <summary>
    /// Interaction logic for f4_a37.xaml
    /// </summary>
    public partial class f4_a37 : UserControl
    {
        public f4_a37()
        {
            InitializeComponent();
        }

        private void Btn_s25_Click(object sender, RoutedEventArgs e)
        {
            // Create a new instance of the gia_cong_truc_f4_a37 window
            var giaCongTrucWindow = new gia_cong_truc_f4_a37();

            // Show the window
            giaCongTrucWindow.Show();
        }
    }
}
