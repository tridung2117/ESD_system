﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using Mitsubishi.tuhocplc.FXcpu;

namespace esd_system.utils
{
    public class PLCLib
    {
        private Enet_Fx3u fx3u; // Mitsubishi PLC object
        private Dictionary<string, string> plcDataResults; // Stores PLC data with Label Name as the key
        private bool isConnected = false;
        private string currentBrand = ""; // Tracks the PLC brand in use

        public PLCLib()
        {
            fx3u = new Enet_Fx3u();
            plcDataResults = new Dictionary<string, string>();
        }

        // Connect to a Mitsubishi PLC
        private void ConnectToMitsu(string ipAddress, int port)
        {
            try
            {
                fx3u.Connect(ipAddress, port);

                if (fx3u.IsConnected)
                {
                    isConnected = true;
                    Console.WriteLine($"Successfully connected to Mitsubishi PLC at {ipAddress}:{port}");
                }
                else
                {
                    isConnected = false;
                    throw new Exception($"Failed to connect to Mitsubishi PLC at {ipAddress}:{port}");
                }
            }
            catch (Exception ex)
            {
                isConnected = false;
                Console.WriteLine($"Error connecting to Mitsubishi PLC: {ex.Message}");
                MessageBox.Show($"Error connecting to Mitsubishi PLC: {ex.Message}", "Connection Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Modular connection logic to handle different PLC brands
        public void ConnectToPLC(string connectionCsvFilePath)
        {
            try
            {
                // Check if the connection CSV file exists
                if (!File.Exists(connectionCsvFilePath))
                {
                    throw new FileNotFoundException("Connection CSV file not found!", connectionCsvFilePath);
                }

                // Read the connection details from the CSV file
                var lines = File.ReadAllLines(connectionCsvFilePath);

                // Ensure the CSV file has at least a header and one row of data
                if (lines.Length <= 1)
                {
                    throw new Exception("Connection CSV file is empty or only contains the header!");
                }

                // Parse the first row of connection details (IP Address, Port, Brand)
                var columns = lines[1].Split(',');

                if (columns.Length != 3)
                {
                    throw new Exception("Invalid format in connection CSV file. Expected format: IP Address,Port,Brand");
                }

                string ipAddress = columns[0].Trim(); // IP Address
                int port = int.Parse(columns[1].Trim()); // Port
                string brand = columns[2].Trim().ToLower(); // PLC Brand

                currentBrand = brand; // Track the current PLC brand

                // Connect based on the PLC brand
                switch (brand)
                {
                    case "mitsu": // Mitsubishi PLC
                        ConnectToMitsu(ipAddress, port);
                        break;

                    default:
                        throw new Exception($"Unsupported PLC brand: {brand}. Only 'mitsu' is supported for now.");
                }
            }
            catch (Exception ex)
            {
                isConnected = false;
                Console.WriteLine($"Error connecting to PLC: {ex.Message}");
                MessageBox.Show($"Error connecting to PLC: {ex.Message}", "Connection Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Read data from the PLC for a single data address
        private string ReadFromMitsu(string dataAddress)
        {
            ushort[] readData = new ushort[1]; // Default value

            if (!isConnected || fx3u == null)
            {
                Console.WriteLine("Not connected to the PLC or fx3u object is null.");
                return readData[0].ToString();
            }

            if (string.IsNullOrEmpty(dataAddress) || !dataAddress.StartsWith("D"))
            {
                Console.WriteLine($"Invalid data address format: {dataAddress}. Must start with 'D'.");
                return readData[0].ToString();
            }

            if (!ushort.TryParse(dataAddress.Substring(1), out ushort address))
            {
                Console.WriteLine($"Failed to parse data address: {dataAddress}. Ensure the address is a valid number after 'D'.");
                return readData[0].ToString();
            }

            bool success = fx3u.MemoryAreaRead(MitsubishiMemory.D, address, 1, out readData);

            if (!success || readData == null || readData.Length == 0)
            {
                Console.WriteLine($"Failed to read data from address: {dataAddress}");
                return readData[0].ToString();
            }

            return readData[0].ToString();
        }

        // Scan and read all label values from the CSV file
        public Dictionary<string, string> ScanAndReadFromCSV(string csvFilePath)
        {
            try
            {
                if (!File.Exists(csvFilePath))
                {
                    throw new FileNotFoundException("Data CSV file not found!", csvFilePath);
                }

                var lines = File.ReadAllLines(csvFilePath);

                if (lines.Length <= 1)
                {
                    throw new Exception("Data CSV file is empty or only contains the header!");
                }

                plcDataResults.Clear(); // Clear previous results

                for (int i = 1; i < lines.Length; i++) // Skip the header
                {
                    var line = lines[i].Trim();
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    var columns = line.Split(',');

                    if (columns.Length != 2)
                    {
                        Console.WriteLine($"Invalid row format at line {i + 1}: {line}");
                        continue;
                    }

                    string labelName = columns[0].Trim();   // Label Name
                    string dataAddress = columns[1].Trim(); // Data Address

                    try
                    {
                        if (isConnected)
                        {
                            string value = ReadFromMitsu(dataAddress);
                            plcDataResults[labelName] = value;
                        }
                        else
                        {
                            plcDataResults[labelName] = "Not connected to PLC";
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error reading data for label '{labelName}': {ex.Message}");
                        plcDataResults[labelName] = "Error";
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing data CSV file: {ex.Message}");
                MessageBox.Show($"Error processing data CSV file: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            return plcDataResults;
        }

        // Continuously read data in a fast cycle
        public void StartFastCycle(string dataCsvFilePath, Action<Dictionary<string, string>> updateCallback, int interval = 1000)
        {
            System.Timers.Timer timer = new System.Timers.Timer(interval);
            timer.Elapsed += (sender, e) =>
            {
                Dictionary<string, string> results = ScanAndReadFromCSV(dataCsvFilePath);

                if (results != null)
                {
                    updateCallback?.Invoke(results);
                }
            };
            timer.AutoReset = true;
            timer.Start();
        }
    }
}