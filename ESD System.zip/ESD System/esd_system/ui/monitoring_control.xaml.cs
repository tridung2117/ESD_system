﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using esd_system.ui.lines_layout.f4_a37;

namespace esd_system.ui
{
    /// <summary>
    /// Interaction logic for monitoring_control.xaml
    /// </summary>
    public partial class monitoring_control : UserControl
    {
        // Dictionary lưu thông tin các line theo xưởng (cả xưởng và line đều là string)
        private Dictionary<string, List<string>> factoryLines = new Dictionary<string, List<string>>();

        public monitoring_control()
        {
            InitializeComponent();
            LoadFactoriesAndLines();
            PopulateFactoryComboBox();
            cbFactory.SelectionChanged += CbFactory_SelectionChanged;
        }

        // 1. Đọc dữ liệu từ CSV và lưu vào Dictionary
        private void LoadFactoriesAndLines()
        {
            string csvFilePath = @"C:\Users\rsd24\Documents\ESD System\esd_system\lines_list\factories_lines.csv";

            // Kiểm tra file có tồn tại không
            if (!File.Exists(csvFilePath))
            {
                throw new FileNotFoundException("Không tìm thấy file factories_lines.csv!");
            }

            // Đọc từng dòng trong file CSV
            var lines = File.ReadAllLines(csvFilePath).Skip(1); // Skip dòng tiêu đề

            foreach (var line in lines)
            {
                var fields = line.Split(','); // Tách bằng dấu phẩy
                string factory = fields[0].Trim(); // Cột 1: Factory (string)
                string lineName = fields[1].Trim(); // Cột 2: Line (string)

                // Thêm vào dictionary
                if (!factoryLines.ContainsKey(factory))
                {
                    factoryLines[factory] = new List<string>();
                }
                factoryLines[factory].Add(lineName);
            }
        }

        // 2. Điền danh sách xưởng vào Combobox cbFactory
        private void PopulateFactoryComboBox()
        {
            cbFactory.Items.Clear();

            foreach (var factory in factoryLines.Keys)
            {
                cbFactory.Items.Add(factory); // Thêm tên xưởng (string)
            }
        }

        // 3. Xử lý sự kiện khi chọn xưởng
        void CbFactory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbFactory.SelectedItem != null)
            {
                string selectedFactory = cbFactory.SelectedItem.ToString(); // Lấy xưởng được chọn (string)

                // Lấy danh sách line của xưởng được chọn
                if (factoryLines.ContainsKey(selectedFactory))
                {
                    Console.WriteLine($"Tìm thấy xưởng {selectedFactory} trong dictionary.");
                    PopulateLineComboBox(factoryLines[selectedFactory]);
                }
            }
        }

        // 4. Điền danh sách line vào Combobox cbLine
        private void PopulateLineComboBox(List<string> lines)
        {
            cbLine.Items.Clear();

            foreach (var line in lines)
            {
                cbLine.Items.Add(line); // Thêm các line tương ứng với xưởng
            }
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            // Assuming cbFactory and cbLine are ComboBoxes
            string selectedFactory = cbFactory.SelectedItem?.ToString();
            string selectedLine = cbLine.SelectedItem?.ToString();

            // Check if the selected values meet the required conditions
            if (selectedFactory == "4" && selectedLine == "A37")
            {
                // Set the content control to the f4_a37 page
                LineContentControl.Content = new f4_a37();
            }
        }
    }
}
