﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using esd_system.ui;
using System.Threading;
using System.IO;
using System.Timers;

namespace esd_system.ui.lines_layout.f4_a37
{
    /// <summary>
    /// Interaction logic for f4_a37.xaml
    /// </summary>
    public partial class f4_a37 : UserControl
    {

        private string CsvFilePath => GetCsvFilePath("measurement_data", "flow_pressure_data.csv");
        private string CsvFileLinePath => GetCsvFilePath("plc_data", "plc_line_data_write.csv");
        private const string LineName = "f4_a37";
        private System.Timers.Timer updateTimer; // Timer for periodic updates

        public f4_a37()
        {
            InitializeComponent();

            // Start reading the CSV file when the form is loaded
            this.Loaded += OnFormLoaded;
            this.Unloaded += OnFormUnloaded;
        }

        /// <summary>
        /// Event triggered when the form is loaded.
        /// </summary>
        private void OnFormLoaded(object sender, RoutedEventArgs e)
        {
            // Initialize the timer
            updateTimer = new System.Timers.Timer(1000); // Set interval to 1 second
            updateTimer.Elapsed += OnTimerElapsed;
            updateTimer.AutoReset = true; // Ensure the timer repeats
            updateTimer.Enabled = true; // Start the timer
        }

        /// <summary>
        /// Event triggered when the form is unloaded.
        /// </summary>
        private void OnFormUnloaded(object sender, RoutedEventArgs e)
        {
            // Stop and dispose of the timer
            if (updateTimer != null)
            {
                updateTimer.Stop();
                updateTimer.Dispose();
            }
        }

        /// <summary>
        /// Dynamically locate the "esd_system" folder.
        /// </summary>
        private string FindEsdSystemFolder()
        {
            string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;

            while (!string.IsNullOrEmpty(currentDirectory))
            {
                string esdSystemPath = System.IO.Path.Combine(currentDirectory, "esd_system");
                if (Directory.Exists(esdSystemPath))
                {
                    return esdSystemPath; // Found the folder
                }

                currentDirectory = System.IO.Path.GetDirectoryName(currentDirectory); // Move up one level
            }

            throw new DirectoryNotFoundException("The 'esd_system' folder could not be found.");
        }

        /// <summary>
        /// Construct a dynamic path to a file in the "esd_system" folder.
        /// </summary>
        private string GetCsvFilePath(string folderName, string fileName)
        {
            string esdSystemFolder = FindEsdSystemFolder();
            return System.IO.Path.Combine(esdSystemFolder, folderName, fileName);
        }

        /// <summary>
        /// Timer callback to read the CSV file and update the UI.
        /// </summary>
        private void OnTimerElapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                // Update flow and pressure data
                UpdateFlowAndPressure();

                // Update button states from plc_line_data_write.csv
                UpdateButtonStates();
            }
            catch (Exception ex)
            {
                // Log or handle errors (for debugging)
                Console.WriteLine($"Error during timer execution: {ex.Message}");
            }
        }

        private void UpdateFlowAndPressure()
        {
            try
            {
                if (File.Exists(CsvFilePath))
                {
                    var lines = File.ReadAllLines(CsvFilePath);

                    // Parse the header to find the relevant columns
                    string[] headers = lines[0].Split(',');
                    int lineIndex = Array.IndexOf(headers, "Line");
                    int flowIndex = Array.IndexOf(headers, "Flow");
                    int pressureIndex = Array.IndexOf(headers, "Pressure");

                    if (lineIndex == -1 || flowIndex == -1 || pressureIndex == -1)
                    {
                        throw new Exception("Required columns (Line, Flow, Pressure) not found in the CSV file.");
                    }

                    // Find the latest data for the specified line
                    var latestLineData = lines
                        .Skip(1) // Skip header row
                        .Select(line => line.Split(','))
                        .Where(columns => columns.Length > Math.Max(lineIndex, Math.Max(flowIndex, pressureIndex)) && columns[lineIndex] == LineName)
                        .LastOrDefault();

                    if (latestLineData != null)
                    {
                        // Parse Flow and Pressure values
                        if (double.TryParse(latestLineData[flowIndex], out double flowValue) &&
                            double.TryParse(latestLineData[pressureIndex], out double pressureValue))
                        {
                            // Update the UI on the main thread
                            Application.Current.Dispatcher.Invoke(() =>
                            {
                                UpdateLuuLuong(flowValue); // Update Flow
                                UpdateApSuat(pressureValue); // Update Pressure
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading flow/pressure data: {ex.Message}");
            }
        }

        private void UpdateButtonStates()
        {
            try
            {
                if (File.Exists(CsvFileLinePath))
                {
                    var lines = File.ReadAllLines(CsvFileLinePath);

                    // Skip the header row and process each row
                    var buttonValues = lines.Skip(1).Select(line => line.Trim()).ToArray();

                    // Update the buttons on the main thread
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        for (int i = 0; i < buttonValues.Length && i < 28; i++) // Limit to 28 buttons
                        {
                            // Get the button by its name (btn_s1 to btn_s28)
                            var buttonName = $"btn_s{i + 1}";
                            var button = FindName(buttonName) as Button;

                            if (button != null && int.TryParse(buttonValues[i], out int value))
                            {
                                // Update the button background based on the value
                                switch (value)
                                {
                                    case 0:
                                        button.Background = Brushes.Red;
                                        break;
                                    case 1:
                                        button.Background = Brushes.Green;
                                        break;
                                    case 2:
                                        button.Background = Brushes.Yellow;
                                        break;
                                    default:
                                        button.Background = Brushes.Gray; // Default color for invalid values
                                        break;
                                }
                            }
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading button states: {ex.Message}");
            }
        }

        /// <summary>
        /// Updates the Lưu lượng khí nén progress circle.
        /// </summary>
        private void UpdateLuuLuong(double flowValue)
        {
            const double maxFlow = 30000; // Example: Maximum flow value
            double percentage = Math.Min((flowValue / maxFlow) * 100, 100);

            // Update text and progress
            PercentageTextLuuLuong.Text = $"{Math.Round(percentage)}%";
            ValueInBarTextLuuLuong.Text = $"{flowValue:F1} l/h";

            // Change color based on alarm condition
            ProgressPathLuuLuong.Stroke = flowValue < 20000 ? Brushes.Red : Brushes.Green;

            // Update the progress arc
            UpdateArc(ProgressPathLuuLuong, percentage);
        }

        /// <summary>
        /// Updates the Áp suất khí nén progress circle.
        /// </summary>
        private void UpdateApSuat(double pressureValue)
        {
            const double maxPressure = 10; // Example: Maximum pressure value
            double percentage = Math.Min((pressureValue / maxPressure) * 100, 100);

            // Update text and progress
            PercentageTextApSuat.Text = $"{Math.Round(percentage)}%";
            ValueInBarTextApSuat.Text = $"{pressureValue:F1} MPa";

            // Change color based on alarm condition
            ProgressPathApSuat.Stroke = pressureValue < 0.5 ? Brushes.Red : Brushes.Green;

            // Update the progress arc
            UpdateArc(ProgressPathApSuat, percentage);
        }

        /// <summary>
        /// Updates the progress arc for a circular graph.
        /// </summary>
        private void UpdateArc(System.Windows.Shapes.Path progressPath, double percentage)
        {
            double centerX = 75; // Center X-coordinate (Grid.Width / 2)
            double centerY = 75 + 25; // Adjust Y-coordinate to account for Grid height (200) and circle height (150)
            double strokeThickness = 10; // Same as the Ellipse's StrokeThickness
            double radius = 65 + (strokeThickness / 2); // Adjust the radius outward by half the StrokeThickness

            double angle = (percentage / 100) * 360;
            double radians = (Math.PI / 180) * angle;

            double startX = centerX;
            double startY = centerY - radius;

            double endX = centerX + radius * Math.Sin(radians);
            double endY = centerY - radius * Math.Cos(radians);

            bool isLargeArc = angle > 180;

            PathFigure pathFigure = new PathFigure { StartPoint = new Point(startX, startY) };

            pathFigure.Segments.Add(new ArcSegment
            {
                Point = new Point(endX, endY),
                Size = new Size(radius, radius),
                SweepDirection = SweepDirection.Clockwise,
                IsLargeArc = isLargeArc
            });

            PathGeometry pathGeometry = new PathGeometry();
            pathGeometry.Figures.Add(pathFigure);
            progressPath.Data = pathGeometry;
        }

        private void Btn_s25_Click(object sender, RoutedEventArgs e)
        {
            // Create a new instance of the gia_cong_truc_f4_a37 window
            var giaCongTrucWindow = new gia_cong_truc_f4_a37();

            giaCongTrucWindow.Show();
        }
    }
}
