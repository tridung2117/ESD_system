﻿using System;
using System.IO; // Keep System.IO for file handling
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Shapes; // Ensure System.Windows.Shapes is included

namespace esd_system
{
    /// <summary>
    /// Interaction logic for UserLogin.xaml
    /// </summary>
    public partial class UserLogin : Window
    {
        public bool IsLoggedIn { get; private set; } = false; // Tracks login status
        public string UserName { get; private set; } = "";    // Stores the user's name
        public string UserLevel { get; private set; } = "";   // Stores the user's privilege level

        public UserLogin()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Password;

            // Get the dynamic CSV file path
            string csvFilePath = GetCsvFilePathUserData("users_list.csv");

            if (File.Exists(csvFilePath))
            {
                try
                {
                    // Read the CSV file
                    var lines = File.ReadAllLines(csvFilePath, Encoding.Unicode);
                    var user = lines
                        .Skip(1) // Skip the header row
                        .Select(line => line.Split(',')) // Split each line by commas
                        .FirstOrDefault(fields => fields.Length >= 4 && fields[0] == username && fields[1] == password); // Find matching user

                    if (user != null)
                    {
                        // Login successful
                        IsLoggedIn = true;
                        UserName = user[2]; // Get the name from the CSV
                        UserLevel = user[3]; // Get the level from the CSV
                        MessageBox.Show($"Welcome, {UserName}!", "Login Successful");

                        this.DialogResult = true; // Close the login window with success
                        return;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error reading user data: {ex.Message}", "Login Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("User data file not found!", "Login Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            // If no match found
            MessageBox.Show("Invalid username or password!", "Login Failed");
            IsLoggedIn = false;
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            IsLoggedIn = false; // Login canceled
            this.DialogResult = false; // Close the dialog
        }

        /// <summary>
        /// Dynamically finds the path to the "users" folder inside "esd_system" and returns the full path to a file.
        /// </summary>
        private string GetCsvFilePathUserData(string fileName)
        {
            string esdSystemFolder = FindEsdSystemFolder();
            return System.IO.Path.Combine(esdSystemFolder, "users", fileName); // Explicitly use System.IO.Path
        }

        /// <summary>
        /// Finds the "esd_system" directory by searching upward from the current directory.
        /// </summary>
        private string FindEsdSystemFolder()
        {
            string directory = AppDomain.CurrentDomain.BaseDirectory;

            while (directory != null && !Directory.Exists(System.IO.Path.Combine(directory, "users"))) // Explicitly use System.IO.Path
            {
                directory = Directory.GetParent(directory)?.FullName;
            }

            return directory ?? AppDomain.CurrentDomain.BaseDirectory;
        }
    }
}